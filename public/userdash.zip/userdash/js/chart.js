



/*==================================== friendly bet chart start here ================================*/

var myChart = echarts.init(document.getElementById('chart-1'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);


var myChart = echarts.init(document.getElementById('chart-2'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);

var myChart = echarts.init(document.getElementById('chart-3'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);
var myChart = echarts.init(document.getElementById('chart-4'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);


/*==================================== friendly bet chart end here ================================*/


 


/*==================================== pool bet chart start here ================================*/

var myChart = echarts.init(document.getElementById('chart-5'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);


var myChart = echarts.init(document.getElementById('chart-6'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);

var myChart = echarts.init(document.getElementById('chart-7'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);
var myChart = echarts.init(document.getElementById('chart-8'));

// 指定图表的配置项和数据
var option = {
  title: {
     
  },
  tooltip: {},
//  legend: {
//    data:['Number of Bets','Friendly Bet lost per month']
//  },
  xAxis: {
    data: ["Jan","Feb","Mar","Apr","May"]
//    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  yAxis: {},
  series: [
    {
	  itemStyle: {normal: {color: '#267766'}},
      name: 'Number of Bets',
      type: 'bar',
      data: [10,1,80,1,40],
    },
    {
	  itemStyle: {normal: {color: '#ffa52f'}},
      name: 'Friendly Bet lost per month',
      type: 'bar',
      data: [10,1,80,1,90]
    },
]
};

myChart.setOption(option);


/*==================================== pool bet chart end here ================================*/

/*==================================== Profile pool bet chart start here ================================*/

//var myChart = echarts.init(document.getElementById('chart-9'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//
//
//var myChart = echarts.init(document.getElementById('chart-10'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//
//
//var myChart = echarts.init(document.getElementById('chart-11'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//
//
//var myChart = echarts.init(document.getElementById('chart-12'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);


 

/*==================================== Profile pool bet chart end here ================================*/


/*==================================== Profile friendly bet chart start here ================================*/
//
//
//
//var myChart = echarts.init(document.getElementById('chart-13'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//
//
//var myChart = echarts.init(document.getElementById('chart-14'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//
//
//var myChart = echarts.init(document.getElementById('chart-15'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//
//
//
//var myChart = echarts.init(document.getElementById('chart-16'));
//
//// 指定图表的配置项和数据
//var option = {
//  title: {
//     
//  },
//  tooltip: {},
////  legend: {
////    data:['Number of Bets','Friendly Bet lost per month']
////  },
//  xAxis: {
//    data: ["Jan","Feb","Mar","Apr","May"]
////    data: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
//  },
//  yAxis: {},
//  series: [
//    {
//	  itemStyle: {normal: {color: '#267766'}},
//      name: 'Number of Bets',
//      type: 'bar',
//      data: [10,1,80,1,40],
//    },
//    {
//	  itemStyle: {normal: {color: '#ffa52f'}},
//      name: 'Friendly Bet lost per month',
//      type: 'bar',
//      data: [10,1,80,1,90]
//    },
//]
//};
//
//myChart.setOption(option);
//




/*==================================== Profile friendly bet chart end here ================================*/







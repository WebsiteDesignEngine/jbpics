/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'es-mx', {
	block: 'Justificar',
	center: 'Centrar',
	left: 'Alinear a la izquierda',
	right: 'Alinear a la derecha'
} );
